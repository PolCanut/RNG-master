package RNG.modelo;

import java.util.ArrayList;

public class ListaClientes extends Lista<Cliente> {

}

package RNG.modelo;

import java.util.ArrayList;

public class ListaArticulos extends Lista<Articulo> {

}
